from chatbot.ai_service import query_gemini_chat
from models.chat_history import ChatHistory

class DisasterChatbot:
    """Class encapsulating disaster response chatbot interactions."""

    @staticmethod
    def get_response(user_id, question, chat_history_context=""):
        """
        Processes user query, queries Gemini AI service with conversation context, 
        and saves exchange to database chat_history.
        """
        if not question or not question.strip():
            return "Please enter a valid question or emergency concern."

        answer = query_gemini_chat(question, chat_history_context=chat_history_context)

        # Save to chat history if logged in
        if user_id:
            try:
                ChatHistory.add_chat(user_id, question, answer)
            except Exception as e:
                print(f"Error saving chat history: {e}")

        return answer

import os
import logging
from config import Config
from chatbot.prompts import EMERGENCY_SYSTEM_PROMPT, MOCK_EMERGENCY_KNOWLEDGE

logger = logging.getLogger('ai_service')

def query_gemini_chat(prompt_text, user_context="", chat_history_context=""):
    """
    Queries Gemini API using official Google GenAI SDK for emergency chatbot answers.
    Maintains multi-turn conversation memory and enforces the 7-section emergency schema.
    Provides structured fallback if offline or API Key pending.
    """
    api_key = Config.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")
    
    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            
            history_prompt = f"Recent Conversation Context:\n{chat_history_context}\n\n" if chat_history_context else ""
            full_prompt = (
                f"{EMERGENCY_SYSTEM_PROMPT}\n\n"
                f"{history_prompt}"
                f"User Question: {prompt_text}\n"
                f"Location/User Context: {user_context}\n\n"
                f"Remember: Answer in clear English, between 100-250 words, using short sentences, "
                f"and strictly follow the 7 section headers (🚨 Situation, ⚠ Immediate Actions, ❌ Avoid, 🎒 Emergency Kit, 📞 Emergency Contacts, 🏥 Nearby Help, ✅ Summary)."
            )
            
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=full_prompt
            )
            if response and response.text:
                return response.text.strip()
        except Exception as e:
            logger.warning(f"Google GenAI SDK call failed: {e}. Trying generativeai fallback...")
            try:
                import google.generativeai as genai_old
                genai_old.configure(api_key=api_key)
                model = genai_old.GenerativeModel('gemini-1.5-flash')
                response = model.generate_content(
                    f"{EMERGENCY_SYSTEM_PROMPT}\n\nContext:\n{chat_history_context}\n\nQuestion: {prompt_text}"
                )
                if response and response.text:
                    return response.text.strip()
            except Exception as ex:
                logger.error(f"Gemini API fallback error: {ex}")

    # Offline / Local fallback match for fast emergency responses
    query_lower = prompt_text.lower()
    for key, text in MOCK_EMERGENCY_KNOWLEDGE.items():
        if key in query_lower:
            return text

    # Default emergency AI guidance response following strict 7-section schema
    return f"""🚨 Situation
Regarding your emergency query ("{prompt_text}"): Instant safety guidance is required for your protection.

⚠ Immediate Actions
• Assess your surroundings for immediate physical or structural hazards.
• Move to high ground or open areas away from unstable walls and wires.
• Dial national emergency helpline 112 for immediate dispatch.
• Keep your mobile phone charged and monitor official emergency alerts.

❌ Avoid
• Don't enter flooded areas, burning buildings, or unstable debris.
• Don't panic or spread unverified rumors.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Ambulance: 108 / 102
• Fire Brigade: 101
• Disaster Relief: 1078

🏥 Nearby Help
Locate your nearest relief shelter, hospital, or police station using the RESCUEAI Shelters map.

✅ Summary
Prioritize immediate safety, stay calm, and contact emergency helpline 112."""

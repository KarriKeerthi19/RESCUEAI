"""
System prompts and context guides for RESCUEAI disaster response intelligence.
"""

EMERGENCY_SYSTEM_PROMPT = """You are RESCUEAI Assistant, an AI Emergency Response Assistant.

Your job is to provide accurate, simple, and life-saving guidance during disasters.

Always answer in clear English.

Never give confusing or unnecessary information.

Always organize your response using headings and bullet points.

If the user asks about floods, earthquakes, cyclones, fires, landslides, tsunamis, heatwaves, building collapses, road accidents, first aid, emergency numbers, shelters, evacuation, or volunteer help, provide practical safety instructions.

Do not generate fictional information.

If information is uncertain, clearly state: "I am not completely certain. Please contact your local emergency authority for confirmation."

Keep responses calm, professional, and reassuring.

Use short sentences.

Prioritize human safety above everything else.

CRITICAL RESPONSE FORMAT REQUIREMENT:
Every response MUST be structured strictly using these exact section headers:

🚨 Situation
[Explain the disaster in 1-2 simple sentences.]

⚠ Immediate Actions
• [Step 1]
• [Step 2]
• [Step 3]
• [Step 4]

❌ Avoid
• [Don't do this 1]
• [Don't do this 2]

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Ambulance: 108 / 102
• Fire Brigade: 101
• Disaster Relief: 1078

🏥 Nearby Help
[Suggest visiting the nearest shelter, hospital, police station, or fire station via RESCUEAI Shelters map.]

✅ Summary
[One short concluding sentence.]

WORD COUNT & STYLE RULES:
- Length: 100–250 words total.
- Emojis ONLY for the section titles listed above.
- Use short sentences and bullet points.
"""

MOCK_EMERGENCY_KNOWLEDGE = {
    "flood": """🚨 Situation
Flash floods cause rapid water level rise, strong currents, and severe contamination hazards.

⚠ Immediate Actions
• Move immediately to higher ground or top floors of sturdy buildings.
• Turn off main electrical switches and gas valves if safe.
• Boil water before drinking or use sealed bottled water.
• Signal for rescue using a flashlight or bright cloth.

❌ Avoid
• Don't walk, swim, or drive through moving floodwater.
• Don't touch fallen power lines or submerged electrical appliances.

🎒 Emergency Kit
• Water (clean drinking water)
• Medicines (first aid & prescriptions)
• Torch (flashlight & batteries)
• Power bank (mobile phone charger)
• Important documents (in waterproof pouch)

📞 Emergency Contacts
• National Helpline: 112
• Ambulance: 108 / 102
• Disaster Relief: 1078

🏥 Nearby Help
Locate your nearest high-ground relief shelter or medical center using the RESCUEAI Shelters map.

✅ Summary
Stay elevated, avoid floodwaters, and wait for official rescue dispatch.""",

    "earthquake": """🚨 Situation
Earthquakes create intense ground shaking that can collapse structures and trigger falling debris.

⚠ Immediate Actions
• DROP to your hands and knees immediately.
• COVER your head and neck under a sturdy table or desk.
• HOLD ON to your shelter until all shaking stops.
• Move away from windows, glass, and exterior walls.

❌ Avoid
• Don't use elevators or run outside during active shaking.
• Don't light matches or lighters due to potential gas leaks.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Ambulance: 108
• Fire Brigade: 101

🏥 Nearby Help
Head to an open outdoor assembly point or nearest emergency medical center once shaking stops.

✅ Summary
Protect your head and neck indoors, and evacuate safely after tremors cease.""",

    "fire": """🚨 Situation
Building and wildfires produce extreme heat, toxic smoke, and rapid flame spread.

⚠ Immediate Actions
• Crawl low under smoke where air is cleaner and cooler.
• Feel door handles with the back of your hand before opening.
• Stop, drop, and roll if your clothing catches fire.
• Evacuate immediately using emergency stairwells.

❌ Avoid
• Don't use elevators during a fire evacuation.
• Don't re-enter a burning building for personal belongings.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• Fire Rescue Brigade: 101
• National Helpline: 112
• Ambulance: 108

🏥 Nearby Help
Evacuate to an exterior assembly point and report to emergency medical teams.

✅ Summary
Get out, stay out, and call fire rescue immediately.""",

    "cyclone": """🚨 Situation
Cyclones bring destructive winds, torrential rainfall, and severe storm surges.

⚠ Immediate Actions
• Stay indoors in a windowless central room or hallway.
• Secure loose outdoor items and shutter all windows.
• Keep mobile phones and battery power banks fully charged.
• Monitor official weather broadcast bulletins constantly.

❌ Avoid
• Don't go outside during the calm eye of the storm.
• Don't drive through coastal storm surges.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Disaster Relief: 1078
• Ambulance: 108

🏥 Nearby Help
Evacuate to designated cyclone shelters mapped in the RESCUEAI Shelters directory.

✅ Summary
Remain inside a reinforced shelter until official all-clear alerts are issued.""",

    "landslide": """🚨 Situation
Landslides involve rapid mud, rock, and debris flows down unstable slopes during heavy rainfall.

⚠ Immediate Actions
• Move away from the path of mudflow or landslide immediately.
• Curl into a tight ball and protect your head if escape is impossible.
• Listen for unusual sounds like cracking trees or knocking boulders.
• Alert nearby neighbors and evacuate to stable high ground.

❌ Avoid
• Don't cross active mudflows or river channels.
• Don't remain inside river valleys or steep embankment zones.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Disaster Relief Force: 1078
• Ambulance: 108

🏥 Nearby Help
Evacuate to designated community shelters away from mountain slopes.

✅ Summary
Stay alert near slopes and evacuate quickly when ground instability occurs.""",

    "tsunami": """🚨 Situation
Tsunamis are massive ocean waves triggered by undersea earthquakes or coastal landslides.

⚠ Immediate Actions
• Move inland to high ground immediately if you feel coastal shaking.
• Evacuate coastal zones when ocean water recedes rapidly.
• Stay at high elevation for several hours after first wave.
• Follow local tsunami siren warnings immediately.

❌ Avoid
• Don't go to the beach to watch a tsunami wave.
• Don't return to low-lying coastal areas until all-clear is given.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Disaster Relief: 1078
• Coast Guard: 1554

🏥 Nearby Help
Seek high-elevation shelters inland away from coastal shorelines.

✅ Summary
Run to high ground immediately following coastal earthquakes or ocean drawdowns.""",

    "heatwave": """🚨 Situation
Extreme heatwaves cause severe dehydration, heat exhaustion, and fatal heatstroke.

⚠ Immediate Actions
• Stay indoors in air-conditioned or shaded cool areas.
• Drink plenty of clean water and oral rehydration salts (ORS).
• Wear lightweight, loose-fitting, light-colored clothing.
• Apply cool damp cloths to neck and forehead during dizziness.

❌ Avoid
• Don't perform heavy physical outdoor work during peak sun hours.
• Don't leave children or pets inside parked vehicles.

🎒 Emergency Kit
• Water (ORS packets & water)
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• Ambulance Services: 108 / 102
• National Helpline: 112

🏥 Nearby Help
Visit cooling centers, hospitals, or emergency clinics if experiencing heatstroke symptoms.

✅ Summary
Hydrate continuously, stay shaded, and protect vulnerable individuals from extreme heat.""",

    "building collapse": """🚨 Situation
Structural building collapses trap victims under heavy concrete, dust, and rubble.

⚠ Immediate Actions
• Cover your nose and mouth with cloth to filter toxic dust.
• Tap on pipes or walls so rescuers can hear your location.
• Cover head and torso under sturdy furniture if trapped.
• Shout only when hearing nearby rescue teams to conserve energy.

❌ Avoid
• Don't ignite matches, lighters, or electrical switches.
• Don't panic or kick dust clouds aggressively.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• Fire Rescue: 101
• National Helpline: 112
• NDRF Rescue: 1078

🏥 Nearby Help
Report to search and rescue command posts and trauma centers immediately.

✅ Summary
Protect your breathing, signal rhythmically on hard surfaces, and await rescue.""",

    "road accident": """🚨 Situation
Severe vehicular accidents require rapid medical triage and scene safety management.

⚠ Immediate Actions
• Call emergency medical services (108 / 112) immediately.
• Ensure the accident scene is safe from oncoming traffic before assisting.
• Apply direct pressure to bleeding wounds using clean cloth.
• Keep injured persons calm and still until paramedics arrive.

❌ Avoid
• Don't move victims with suspected neck or spine injuries.
• Don't give food or water to an unconscious victim.

🎒 Emergency Kit
• Water
• Medicines (First Aid Supplies)
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• Ambulance: 108 / 102
• Police Control: 100 / 112
• Fire Brigade: 101

🏥 Nearby Help
Transport critically injured persons to the nearest trauma hospital via ambulance.

✅ Summary
Call 108 immediately, stabilize bleeding, and do not move spinal injury victims.""",

    "first aid": """🚨 Situation
Emergency first aid provides immediate stabilization for hemorrhage, cardiac arrest, or burns.

⚠ Immediate Actions
• CPR: Press hard and fast in center of chest (100-120 compressions/min).
• Bleeding: Apply firm direct pressure with clean cloth over wound.
• Burns: Cool with running tap water for 10-20 minutes.
• Recovery Position: Turn unconscious breathing person onto their side.

❌ Avoid
• Don't apply ice, butter, or oil to thermal burns.
• Don't remove deeply embedded objects from wounds.

🎒 Emergency Kit
• Water
• Medicines (Bandages, antiseptics, sterile gauze)
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• Ambulance / Medical Dispatch: 108 / 102
• National Helpline: 112

🏥 Nearby Help
Seek emergency medical treatment at the nearest hospital or health clinic.

✅ Summary
Apply firm pressure to bleeding, perform chest compressions for CPR, and call 108.""",

    "emergency numbers": """🚨 Situation
National emergency helpline directory for immediate police, fire, ambulance, and disaster dispatch.

⚠ Immediate Actions
• Dial 112 for all-in-one National Emergency Dispatch.
• Dial 108 / 102 for Medical Ambulance & Trauma Dispatch.
• Dial 101 for Fire Brigade & Heavy Rescue Services.
• Dial 1078 for NDRF Disaster Relief Command.

❌ Avoid
• Don't make non-emergency test calls to 112 emergency lines.
• Don't hang up before giving your location.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Ambulance: 108 / 102
• Fire Brigade: 101
• Disaster Relief: 1078

🏥 Nearby Help
Contact your nearest local police station, fire station, or hospital.

✅ Summary
Keep 112, 108, and 101 saved on speed dial for immediate emergency response.""",

    "shelter": """🚨 Situation
Emergency relief shelters provide safe lodging, food, medical care, and clean water during disasters.

⚠ Immediate Actions
• Check the RESCUEAI Shelters map to locate safe refuges.
• Pack your 72-hour emergency survival bag before evacuating.
• Register your family details with shelter administration upon arrival.
• Follow shelter officer instructions for sanitation and resource sharing.

❌ Avoid
• Don't remain in flood zones or damaged homes when shelters are open.
• Don't leave pets behind if safe transport is available.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Disaster Relief: 1078
• Shelter Helpline: 108

🏥 Nearby Help
Access designated community centers, schools, and hospitals on RESCUEAI Shelters map.

✅ Summary
Evacuate early to designated relief shelters for safe accommodation and medical care.""",

    "evacuation": """🚨 Situation
Emergency evacuations safely clear citizens from high-risk flood, fire, or storm surge zones.

⚠ Immediate Actions
• Evacuate immediately when local authorities issue warnings.
• Grab your emergency survival bag and lock all doors/windows.
• Follow designated evacuation routes; avoid shortcuts through water.
• Assist elderly neighbors, children, and persons with disabilities.

❌ Avoid
• Don't delay evacuation to gather non-essential household items.
• Don't drive across flooded bridges or barricaded roads.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Police Dispatch: 100
• Disaster Relief: 1078

🏥 Nearby Help
Proceed along official evacuation corridors to registered relief shelters.

✅ Summary
Evacuate immediately along safe routes when official warnings are issued.""",

    "volunteer": """🚨 Situation
Community volunteer mobilization connects responders with relief distribution and rescue tasks.

⚠ Immediate Actions
• Register your skills (CPR, 4x4 driving, medical) on RESCUEAI Volunteer portal.
• Coordinate with local command centers for food and supply distribution.
• Wear high-visibility safety gear during relief operations.
• Maintain team communication and report emergency hazards immediately.

❌ Avoid
• Don't enter unstable hazard zones without safety gear or authorization.
• Don't work alone in disaster zones; use buddy system.

🎒 Emergency Kit
• Water
• Medicines
• Torch
• Power bank
• Important documents

📞 Emergency Contacts
• National Helpline: 112
• Volunteer Coordinator: 1078
• Ambulance: 108

🏥 Nearby Help
Report to designated volunteer staging hubs and relief centers.

✅ Summary
Register on RESCUEAI Volunteer portal to assist community relief operations safely."""
}

import sqlite3
import os
import logging
from config import Config

try:
    import pymysql
    import pymysql.cursors
    HAS_PYMYSQL = True
except ImportError:
    HAS_PYMYSQL = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('database')

# Define SQLite fallback file path if MySQL connection is unavailable
SQLITE_DB_PATH = os.path.join(Config.BASE_DIR, 'rescueai.db')

def get_db_connection():
    """
    Establishes and returns a database connection.
    Attempts MySQL connection first if pymysql is available; falls back to SQLite for seamless execution.
    """
    if HAS_PYMYSQL:
        try:
            connection = pymysql.connect(
                host=Config.MYSQL_HOST,
                user=Config.MYSQL_USER,
                password=Config.MYSQL_PASSWORD,
                database=Config.MYSQL_DB,
                port=Config.MYSQL_PORT,
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=True
            )
            return connection, 'mysql'
        except Exception as e:
            logger.warning(f"MySQL Connection could not be established ({e}). Using SQLite fallback database: {SQLITE_DB_PATH}")

    conn = sqlite3.connect(SQLITE_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn, 'sqlite'

def execute_query(query, params=(), fetch_one=False, fetch_all=False):
    """
    Executes parameterized SQL queries safely to prevent SQL injection.
    Handles differences between MySQL (%s) and SQLite (?) placeholders dynamically.
    """
    conn, db_type = get_db_connection()
    try:
        # Adapt SQL parameter placeholders for SQLite if needed
        if db_type == 'sqlite':
            adapted_query = query.replace('%s', '?')
        else:
            adapted_query = query

        if db_type == 'sqlite':
            cursor = conn.cursor()
            cursor.execute(adapted_query, params)
            conn.commit()
            
            if fetch_one:
                row = cursor.fetchone()
                return dict(row) if row else None
            if fetch_all:
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
            return cursor.lastrowid
        else:
            with conn.cursor() as cursor:
                cursor.execute(adapted_query, params)
                if fetch_one:
                    return cursor.fetchone()
                if fetch_all:
                    return cursor.fetchall()
                return cursor.lastrowid
    except Exception as e:
        logger.error(f"Database Query Error: {e} | Query: {query}")
        return None
    finally:
        conn.close()

def init_db():
    """
    Initializes all database tables required by the RESCUEAI application.
    Creates MySQL database if missing, and creates all schemas and seed data.
    """
    # 1. First try creating MySQL database if pymysql is present
    if HAS_PYMYSQL:
        try:
            conn = pymysql.connect(
                host=Config.MYSQL_HOST,
                user=Config.MYSQL_USER,
                password=Config.MYSQL_PASSWORD,
                port=Config.MYSQL_PORT,
                autocommit=True
            )
            with conn.cursor() as cursor:
                cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.MYSQL_DB};")
            conn.close()
            logger.info(f"MySQL database '{Config.MYSQL_DB}' verified/created.")
        except Exception as e:
            logger.warning(f"Could not initialize MySQL database directly ({e}). Proceeding to schema setup.")

    # 2. Table Schemas DDL
    queries = [
        """
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            phone VARCHAR(20) NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS disaster_reports (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            title VARCHAR(150) NOT NULL,
            description TEXT NOT NULL,
            image VARCHAR(255),
            location VARCHAR(255) NOT NULL,
            severity VARCHAR(50) DEFAULT 'Medium',
            status VARCHAR(50) DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS sos_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            latitude VARCHAR(50) NOT NULL,
            longitude VARCHAR(50) NOT NULL,
            status VARCHAR(50) DEFAULT 'ACTIVE',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS shelters (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(150) NOT NULL,
            address VARCHAR(255) NOT NULL,
            capacity INT DEFAULT 100,
            latitude VARCHAR(50),
            longitude VARCHAR(50)
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS volunteers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            skills TEXT NOT NULL,
            availability VARCHAR(100) NOT NULL,
            status VARCHAR(50) DEFAULT 'Active'
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(150) NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS chat_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS ai_reports (
            id INT AUTO_INCREMENT PRIMARY KEY,
            report_id INT,
            summary TEXT NOT NULL,
            recommendation TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """
    ]

    conn, db_type = get_db_connection()
    try:
        if db_type == 'sqlite':
            cursor = conn.cursor()
            for q in queries:
                sqlite_q = q.replace('INT AUTO_INCREMENT PRIMARY KEY', 'INTEGER PRIMARY KEY AUTOINCREMENT')
                sqlite_q = sqlite_q.replace('TIMESTAMP DEFAULT CURRENT_TIMESTAMP', 'DATETIME DEFAULT CURRENT_TIMESTAMP')
                cursor.execute(sqlite_q)
            conn.commit()
        else:
            with conn.cursor() as cursor:
                for q in queries:
                    cursor.execute(q)

        logger.info(f"All database tables verified/created successfully using {db_type.upper()}.")

        # 3. Seed Default Shelters & Admin Account if tables are empty
        seed_db(conn, db_type)

    except Exception as e:
        logger.error(f"Error during schema initialization: {e}")
    finally:
        conn.close()

def seed_db(conn, db_type):
    """Seeds default emergency shelters and notifications if none exist."""
    from werkzeug.security import generate_password_hash
    
    # Check if shelters table is empty
    shelters = execute_query("SELECT COUNT(*) as count FROM shelters", fetch_one=True)
    if shelters and shelters.get('count', 0) == 0:
        default_shelters = [
            ("Central Community Crisis Shelter", "12 Main St, Downtown Metro", 250, "28.6139", "77.2090"),
            ("East Hill Disaster Relief Center", "88 East High Road", 150, "28.6250", "77.2150"),
            ("St. Jude Emergency Hospital & Shelter", "404 Relief Ave", 300, "28.6050", "77.1950"),
            ("Northside Indoor Stadium & Refuge", "90 Stadium Drive", 500, "28.6380", "77.2210")
        ]
        for s in default_shelters:
            execute_query(
                "INSERT INTO shelters (name, address, capacity, latitude, longitude) VALUES (%s, %s, %s, %s, %s)",
                s
            )

    # Check if default admin account exists
    admin = execute_query("SELECT * FROM users WHERE email = %s", ('admin@rescueai.org',), fetch_one=True)
    if not admin:
        hashed_pw = generate_password_hash("admin123")
        execute_query(
            "INSERT INTO users (name, email, phone, password, role) VALUES (%s, %s, %s, %s, %s)",
            ("RESCUEAI System Admin", "admin@rescueai.org", "1800-RESCUE-AI", hashed_pw, "admin")
        )

    # Check if initial emergency alert notification exists
    notifs = execute_query("SELECT COUNT(*) as count FROM notifications", fetch_one=True)
    if notifs and notifs.get('count', 0) == 0:
        execute_query(
            "INSERT INTO notifications (title, message) VALUES (%s, %s)",
            ("HIGH ALERT: Heavy Rainfall & Flood Advisory", "Emergency services on active alert. Please check nearby shelters and submit SOS if immediate evacuation is needed.")
        )

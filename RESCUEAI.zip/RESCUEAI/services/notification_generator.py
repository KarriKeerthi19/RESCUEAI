import os
import logging
from config import Config

logger = logging.getLogger('notification_generator')

def generate_ai_summary_all_reports(reports_list):
    """
    Summarizes multiple disaster reports for Admin Dashboard overview using Gemini API.
    """
    if not reports_list:
        return "No disaster reports available to summarize."

    api_key = Config.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")

    reports_text = "\n".join([
        f"- ID #{r.get('id')}: {r.get('title')} at {r.get('location')} (Severity: {r.get('severity')}, Status: {r.get('status')})"
        for r in reports_list
    ])

    prompt = f"""
    You are an emergency command center AI executive. Summarize the following disaster reports into a concise executive briefing:
    
    Reports Data:
    {reports_text}
    
    Provide:
    1. Overall Situation Overview
    2. Key Hotspot Locations needing urgent attention
    3. Resource Allocation Recommendations
    """

    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )
            if response and response.text:
                return response.text
        except Exception as e:
            logger.warning(f"Gemini API summary failed: {e}")

    # Fallback executive summary
    total = len(reports_list)
    critical_count = sum(1 for r in reports_list if r.get('severity', '').lower() in ['critical', 'high'])
    locations = set(r.get('location', 'Unknown') for r in reports_list)
    loc_str = ", ".join(list(locations)[:4])

    return f"""
📢 **EXECUTIVE DISASTER BRIEFING ({total} Active Reports)**

- **Situation Overview**: Command center is currently tracking {total} reported incident(s). {critical_count} report(s) are classified as Critical or High severity requiring rapid response team deployment.
- **Hotspot Locations**: Primary affected regions include: **{loc_str}**.
- **Resource Allocation Recommendation**: Prioritize dispatching medical and search & rescue teams to Critical status locations. Keep nearest shelters prepared for incoming displaced citizens.
    """.strip()

def generate_public_emergency_alert(disaster_type, region, severity_level):
    """
    Generates a public broadcast alert string using Gemini AI.
    """
    api_key = Config.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")

    prompt = f"Write a clear, urgent broadcast emergency notification for citizens regarding a {severity_level} {disaster_type} in {region}. Keep it under 60 words."

    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )
            if response and response.text:
                return response.text.strip()
        except Exception as e:
            logger.warning(f"Gemini alert prompt failed: {e}")

    return f"🚨 EMERGENCY ADVISORY ({severity_level.upper()}): A {disaster_type} situation has been reported in {region}. All residents are urged to remain indoors, stay on high ground, and follow local authority instructions. Stay tuned to RESCUEAI."

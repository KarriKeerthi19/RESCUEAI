import os
import logging
from config import Config

logger = logging.getLogger('report_generator')

def generate_ai_damage_report(title, description, location, severity, vision_analysis=None):
    """
    Generates a full AI disaster damage report using Gemini API.
    Structures:
    - Incident Description
    - Infrastructure Damage
    - Casualties Assessment
    - Road Condition
    - Power Supply Status
    - Recommended Action Plan
    """
    api_key = Config.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")

    prompt = f"""
    You are an emergency response AI analyst. Generate a comprehensive Damage Assessment Report for the following incident:
    
    Incident Title: {title}
    Location: {location}
    Reported Severity: {severity}
    User Description: {description}
    Vision Analysis Details: {vision_analysis or 'No image provided'}
    
    Provide structured text output covering:
    1. Executive Summary & Incident Description
    2. Infrastructure Damage Assessment
    3. Casualties & Human Impact Warning
    4. Road & Transportation Conditions
    5. Power & Utility Supply Status
    6. Priority Rescue & Relief Action Plan
    """

    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )
            if response and response.text:
                return response.text
        except Exception as e:
            logger.warning(f"Gemini API report generation failed: {e}. Falling back to dynamic template generator.")

    # Dynamic structured fallback report
    infrastructure_status = "Moderate to severe structural impact reported near primary transport corridors."
    if "high" in severity.lower() or "critical" in severity.lower():
        road_status = "⚠️ BLOCKED / IMPASSABLE - Debris and water accumulation restricting emergency vehicle access."
        power_status = "🔴 DISRUPTED - Power lines downed or isolated for emergency safety precautions."
        action_plan = "Deploy heavy equipment to clear access routes; dispatch search & rescue teams with amphibious units."
    else:
        road_status = "🟡 PASSABLE WITH CAUTION - Minor obstruction; slow speed mandatory."
        power_status = "🟡 PARTIAL OUTAGE - Secondary transformers affected; emergency grid active."
        action_plan = "Deploy field assessment team, establish local emergency aid camp, issue community advisory."

    report_text = f"""
📋 **RESCUEAI DETAILED DAMAGE ASSESSMENT REPORT**

**1. Executive Summary & Incident Description:**
Emergency report logged for "{title}" at location: **{location}**. Classified under **{severity}** severity. 
{description}

**2. Infrastructure Damage Assessment:**
{vision_analysis.get('damage_summary', infrastructure_status) if isinstance(vision_analysis, dict) else infrastructure_status}

**3. Casualties & Human Impact Warning:**
No immediate confirmed fatalities in initial user log. First responders must verify on-scene. Local citizens advised to stay clear of unstable structures.

**4. Road & Transportation Conditions:**
{road_status}

**5. Power & Utility Supply Status:**
{power_status}

**6. Recommended Action Plan:**
{action_plan}
    """.strip()

    return report_text

/**
 * RESCUEAI - AI Emergency Response System JS Core Utility & Particle Canvas Engine
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log("RESCUEAI Dark Glass Design Engine Loaded.");

    // Initialize Particle Canvas Background if element exists
    initParticleCanvas();

    // Initialize Counter Animations for stats elements
    animateCounters();

    // Auto-dismiss alert notifications after 6 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 6000);
    });

    // Dynamic Progress Bar width calculation from data-pct
    document.querySelectorAll('.progress-bar[data-pct]').forEach(bar => {
        const pct = bar.getAttribute('data-pct');
        if (pct) {
            bar.style.width = pct + '%';
        }
    });

    // Facility filter button handlers on Shelters page
    const filterBtns = document.querySelectorAll('.filter-btn');
    if (filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                filterBtns.forEach(b => {
                    b.classList.remove('active', 'btn-cyan', 'btn-primary');
                    b.classList.add('btn-glass');
                });

                this.classList.add('active', 'btn-cyan');
                this.classList.remove('btn-glass');

                const filterType = this.getAttribute('data-type');
                document.querySelectorAll('.shelter-card').forEach(card => {
                    const cardType = card.getAttribute('data-type');
                    if (filterType === 'all' || cardType === filterType) {
                        card.style.setProperty('display', 'block', 'important');
                    } else {
                        card.style.setProperty('display', 'none', 'important');
                    }
                });
            });
        });
    }

    // Initialize Client-side Table Search if input exists
    const searchInputs = document.querySelectorAll('[data-table-search]');
    searchInputs.forEach(input => {
        const targetTableId = input.getAttribute('data-table-search');
        input.addEventListener('keyup', function() {
            filterTableRows(this.value, targetTableId);
        });
    });
});

/**
 * Interactive Particle Canvas Background Engine
 */
function initParticleCanvas() {
    let canvas = document.getElementById('particleCanvas');
    if (!canvas) {
        canvas = document.createElement('canvas');
        canvas.id = 'particleCanvas';
        document.body.prepend(canvas);
    }

    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const count = Math.floor((width * height) / 22000);

    for (let i = 0; i < count; i++) {
        particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            vx: (Math.random() - 0.5) * 0.4,
            vy: (Math.random() - 0.5) * 0.4,
            radius: Math.random() * 2 + 1,
            color: Math.random() > 0.4 ? 'rgba(0, 212, 255, ' : 'rgba(59, 130, 246, ',
            alpha: Math.random() * 0.5 + 0.2
        });
    }

    function render() {
        ctx.clearRect(0, 0, width, height);

        for (let i = 0; i < particles.length; i++) {
            let p = particles[i];
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0 || p.x > width) p.vx *= -1;
            if (p.y < 0 || p.y > height) p.vy *= -1;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = p.color + p.alpha + ')';
            ctx.fill();

            // Connect nearby particles
            for (let j = i + 1; j < particles.length; j++) {
                let p2 = particles[j];
                let dist = Math.hypot(p.x - p2.x, p.y - p2.y);
                if (dist < 110) {
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.strokeStyle = `rgba(0, 212, 255, ${0.15 * (1 - dist / 110)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(render);
    }
    render();
}

/**
 * Animated Counters for Numerical Elements
 */
function animateCounters() {
    const counterElements = document.querySelectorAll('[data-counter-target]');
    counterElements.forEach(el => {
        const target = parseInt(el.getAttribute('data-counter-target') || el.innerText, 10);
        if (isNaN(target)) return;

        let current = 0;
        const duration = 1200;
        const stepTime = 30;
        const steps = duration / stepTime;
        const increment = target / steps;

        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                el.innerText = target.toLocaleString();
                clearInterval(timer);
            } else {
                el.innerText = Math.floor(current).toLocaleString();
            }
        }, stepTime);
    });
}

/**
 * Table Search Filter Functionality
 */
function filterTableRows(query, tableId) {
    const table = document.getElementById(tableId);
    if (!table) return;
    const filter = query.toLowerCase();
    const rows = table.querySelectorAll('tbody tr');

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}

/**
 * Display & Hide Loading Overlay
 */
function showGlobalSpinner() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) overlay.classList.remove('d-none');
}

function hideGlobalSpinner() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) overlay.classList.add('d-none');
}

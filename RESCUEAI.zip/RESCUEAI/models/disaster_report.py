from database import execute_query

class DisasterReport:
    """DisasterReport model for handling user disaster reports and AI analyses."""

    @staticmethod
    def create_report(user_id, title, description, image, location, severity='Medium', status='Pending'):
        """Inserts a new disaster report into the database."""
        query = """
            INSERT INTO disaster_reports (user_id, title, description, image, location, severity, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        return execute_query(query, (user_id, title, description, image, location, severity, status))

    @staticmethod
    def get_by_id(report_id):
        """Fetches a disaster report by report ID."""
        query = """
            SELECT dr.*, u.name as user_name, u.phone as user_phone
            FROM disaster_reports dr
            LEFT JOIN users u ON dr.user_id = u.id
            WHERE dr.id = %s
        """
        return execute_query(query, (report_id,), fetch_one=True)

    @staticmethod
    def get_by_user(user_id):
        """Fetches disaster reports submitted by a specific user."""
        query = "SELECT * FROM disaster_reports WHERE user_id = %s ORDER BY created_at DESC"
        return execute_query(query, (user_id,), fetch_all=True)

    @staticmethod
    def get_all_reports():
        """Fetches all disaster reports with user details for admin/dashboard."""
        query = """
            SELECT dr.*, u.name as user_name
            FROM disaster_reports dr
            LEFT JOIN users u ON dr.user_id = u.id
            ORDER BY dr.created_at DESC
        """
        return execute_query(query, fetch_all=True)

    @staticmethod
    def get_recent(limit=5):
        """Fetches the N most recent disaster reports."""
        query = """
            SELECT dr.*, u.name as user_name
            FROM disaster_reports dr
            LEFT JOIN users u ON dr.user_id = u.id
            ORDER BY dr.created_at DESC LIMIT %s
        """
        return execute_query(query, (limit,), fetch_all=True)

    @staticmethod
    def update_status(report_id, status):
        """Updates status (e.g. Pending, Verified, Resolved) of a report."""
        query = "UPDATE disaster_reports SET status = %s WHERE id = %s"
        return execute_query(query, (status, report_id))

    @staticmethod
    def get_total_count():
        """Returns total report count."""
        res = execute_query("SELECT COUNT(*) as count FROM disaster_reports", fetch_one=True)
        return res['count'] if res else 0

    @staticmethod
    def save_ai_summary(report_id, summary, recommendation):
        """Stores AI generated summary and recommendation in ai_reports table."""
        query = """
            INSERT INTO ai_reports (report_id, summary, recommendation)
            VALUES (%s, %s, %s)
        """
        return execute_query(query, (report_id, summary, recommendation))

    @staticmethod
    def get_ai_summary(report_id):
        """Fetches AI summary for a specific disaster report."""
        query = "SELECT * FROM ai_reports WHERE report_id = %s ORDER BY created_at DESC"
        return execute_query(query, (report_id,), fetch_one=True)

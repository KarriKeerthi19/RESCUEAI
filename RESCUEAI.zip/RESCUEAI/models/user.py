from database import execute_query
from werkzeug.security import generate_password_hash, check_password_hash

class User:
    """User model for managing user registration, authentication, and user queries."""

    @staticmethod
    def create_user(name, email, phone, password, role='user'):
        """Hashes password and creates a new user in the database."""
        hashed_password = generate_password_hash(password)
        query = """
            INSERT INTO users (name, email, phone, password, role)
            VALUES (%s, %s, %s, %s, %s)
        """
        user_id = execute_query(query, (name, email, phone, hashed_password, role))
        return user_id

    @staticmethod
    def find_by_email(email):
        """Fetches a user record by email address."""
        query = "SELECT * FROM users WHERE email = %s"
        return execute_query(query, (email,), fetch_one=True)

    @staticmethod
    def find_by_id(user_id):
        """Fetches user details by user ID."""
        query = "SELECT id, name, email, phone, role, created_at FROM users WHERE id = %s"
        return execute_query(query, (user_id,), fetch_one=True)

    @staticmethod
    def verify_password(stored_password_hash, provided_password):
        """Verifies if the provided password matches the stored hash."""
        return check_password_hash(stored_password_hash, provided_password)

    @staticmethod
    def get_all_users():
        """Returns all registered users for admin dashboard."""
        query = "SELECT id, name, email, phone, role, created_at FROM users ORDER BY id DESC"
        return execute_query(query, fetch_all=True)

    @staticmethod
    def get_total_count():
        """Returns total user count."""
        result = execute_query("SELECT COUNT(*) as count FROM users", fetch_one=True)
        return result['count'] if result else 0

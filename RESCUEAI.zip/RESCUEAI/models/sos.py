from database import execute_query

class SOSRequest:
    """SOSRequest model for managing high-priority emergency SOS panic signals."""

    @staticmethod
    def create_sos(user_id, latitude, longitude, status='ACTIVE'):
        """Registers a new high-priority SOS emergency signal with location coordinates."""
        query = """
            INSERT INTO sos_requests (user_id, latitude, longitude, status)
            VALUES (%s, %s, %s, %s)
        """
        return execute_query(query, (user_id, latitude, longitude, status))

    @staticmethod
    def get_active_sos():
        """Fetches active SOS emergency requests with user contact details."""
        query = """
            SELECT s.*, u.name as user_name, u.phone as user_phone
            FROM sos_requests s
            LEFT JOIN users u ON s.user_id = u.id
            WHERE s.status = 'ACTIVE'
            ORDER BY s.created_at DESC
        """
        return execute_query(query, fetch_all=True)

    @staticmethod
    def get_all_sos():
        """Fetches all SOS requests for admin monitoring."""
        query = """
            SELECT s.*, u.name as user_name, u.phone as user_phone
            FROM sos_requests s
            LEFT JOIN users u ON s.user_id = u.id
            ORDER BY s.created_at DESC
        """
        return execute_query(query, fetch_all=True)

    @staticmethod
    def update_status(sos_id, status):
        """Updates SOS status (ACTIVE, RESPONDED, RESOLVED)."""
        query = "UPDATE sos_requests SET status = %s WHERE id = %s"
        return execute_query(query, (status, sos_id))

    @staticmethod
    def get_total_active_count():
        """Returns total active SOS count."""
        res = execute_query("SELECT COUNT(*) as count FROM sos_requests WHERE status = 'ACTIVE'", fetch_one=True)
        return res['count'] if res else 0

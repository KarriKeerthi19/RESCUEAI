from database import execute_query

class ChatHistory:
    """ChatHistory model for storing user AI interaction logs for emergency audits."""

    @staticmethod
    def add_chat(user_id, question, answer):
        """Stores a chat exchange between user and RESCUEAI Chatbot."""
        query = "INSERT INTO chat_history (user_id, question, answer) VALUES (%s, %s, %s)"
        return execute_query(query, (user_id, question, answer))

    @staticmethod
    def get_by_user(user_id, limit=20):
        """Fetches chat history for a specific user."""
        query = "SELECT * FROM chat_history WHERE user_id = %s ORDER BY created_at ASC LIMIT %s"
        return execute_query(query, (user_id, limit), fetch_all=True)

    @staticmethod
    def clear_user_chat(user_id):
        """Clears chat history for a user."""
        query = "DELETE FROM chat_history WHERE user_id = %s"
        return execute_query(query, (user_id,))

from database import execute_query

class Shelter:
    """Shelter model for managing emergency shelters, medical relief centers, and locations."""

    @staticmethod
    def create_shelter(name, address, capacity, latitude, longitude):
        """Creates a new shelter entry."""
        query = """
            INSERT INTO shelters (name, address, capacity, latitude, longitude)
            VALUES (%s, %s, %s, %s, %s)
        """
        return execute_query(query, (name, address, capacity, latitude, longitude))

    @staticmethod
    def get_all_shelters():
        """Fetches all registered shelters."""
        query = "SELECT * FROM shelters ORDER BY id ASC"
        return execute_query(query, fetch_all=True)

    @staticmethod
    def get_by_id(shelter_id):
        """Fetches a specific shelter by ID."""
        query = "SELECT * FROM shelters WHERE id = %s"
        return execute_query(query, (shelter_id,), fetch_one=True)

    @staticmethod
    def get_total_count():
        """Returns total shelters count."""
        res = execute_query("SELECT COUNT(*) as count FROM shelters", fetch_one=True)
        return res['count'] if res else 0

    @staticmethod
    def update_shelter(shelter_id, name, address, capacity, latitude, longitude):
        """Updates shelter information."""
        query = """
            UPDATE shelters
            SET name = %s, address = %s, capacity = %s, latitude = %s, longitude = %s
            WHERE id = %s
        """
        return execute_query(query, (name, address, capacity, latitude, longitude, shelter_id))

    @staticmethod
    def delete_shelter(shelter_id):
        """Deletes a shelter record."""
        query = "DELETE FROM shelters WHERE id = %s"
        return execute_query(query, (shelter_id,))

from database import execute_query

class Volunteer:
    """Volunteer model for managing community disaster relief responders and tasks."""

    @staticmethod
    def register_volunteer(user_id, skills, availability, status='Active'):
        """Registers a user as a disaster response volunteer."""
        query = """
            INSERT INTO volunteers (user_id, skills, availability, status)
            VALUES (%s, %s, %s, %s)
        """
        return execute_query(query, (user_id, skills, availability, status))

    @staticmethod
    def get_by_user_id(user_id):
        """Fetches volunteer profile by user ID."""
        query = "SELECT * FROM volunteers WHERE user_id = %s"
        return execute_query(query, (user_id,), fetch_one=True)

    @staticmethod
    def get_all_volunteers():
        """Fetches all registered volunteers with user details."""
        query = """
            SELECT v.*, u.name as user_name, u.email as user_email, u.phone as user_phone
            FROM volunteers v
            LEFT JOIN users u ON v.user_id = u.id
            ORDER BY v.id DESC
        """
        return execute_query(query, fetch_all=True)

    @staticmethod
    def update_status(volunteer_id, status):
        """Updates volunteer status (Active, Assigned, Inactive)."""
        query = "UPDATE volunteers SET status = %s WHERE id = %s"
        return execute_query(query, (status, volunteer_id))

    @staticmethod
    def get_total_count():
        """Returns total volunteer count."""
        res = execute_query("SELECT COUNT(*) as count FROM volunteers", fetch_one=True)
        return res['count'] if res else 0

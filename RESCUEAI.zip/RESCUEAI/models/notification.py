from database import execute_query

class Notification:
    """Notification model for broadcasting emergency alerts to citizens."""

    @staticmethod
    def create_notification(title, message):
        """Creates a new broadcast emergency notification alert."""
        query = "INSERT INTO notifications (title, message) VALUES (%s, %s)"
        return execute_query(query, (title, message))

    @staticmethod
    def get_latest_notifications(limit=10):
        """Fetches latest emergency alerts."""
        query = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT %s"
        return execute_query(query, (limit,), fetch_all=True)

    @staticmethod
    def get_all_notifications():
        """Fetches all notifications."""
        query = "SELECT * FROM notifications ORDER BY created_at DESC"
        return execute_query(query, fetch_all=True)

    @staticmethod
    def delete_notification(notification_id):
        """Deletes a notification alert."""
        query = "DELETE FROM notifications WHERE id = %s"
        return execute_query(query, (notification_id,))

# RESCUEAI – AI-Powered Disaster Response & Emergency Assistance System

![RESCUEAI Hero](static/images/hero.jpg)

**RESCUEAI** is a state-of-the-art web application built for emergency response, disaster relief mobilization, and citizen assistance during natural disasters (floods, cyclones, earthquakes, landslides, fires). Powered by **Google Gemini API (Gemini 2.5 Flash / Gemini Vision)** and **Google Maps API**, RESCUEAI provides real-time intelligent disaster image damage analysis, automated PDF damage audit reports, instant CPR & first-aid chatbot advice, panic SOS GPS signal broadcasting, and interactive shelter locator maps.

---

## 🌟 Key Features

1. **AI Emergency Chatbot**: Real-time disaster safety rules, CPR instructions, first aid procedures, emergency numbers, and survival kit checklist powered by Gemini API.
2. **AI Image Analysis**: Upload disaster photos for scene evaluation using Gemini Vision API. Detects disaster type, severity rating, structural hazards, objects detected, and confidence score.
3. **AI Damage Report Generator**: Automatically compiles structured damage reports detailing incident description, infrastructure damage, casualties warning, road conditions, power supply status, and recommended action plan.
4. **PDF Report Downloader**: Generates official downloadable PDF damage reports using ReportLab.
5. **SOS Panic Beacon**: High-priority panic trigger that locks HTML5 GPS location coordinates and alerts first responders.
6. **Smart Shelter & Hospital Map**: Interactive map displaying nearby safe refuges, emergency trauma centers, police stations, and fire departments with capacity tracking.
7. **Volunteer Mobilization**: Community registration portal matching volunteers with urgent relief tasks.
8. **Admin Command Center**: Complete dashboard for verifying disaster reports, managing users/shelters, broadcasting public warnings, and generating AI multi-report summaries.

---

## 🛠️ Technology Stack

- **Backend**: Python 3.10+, Flask, Flask Blueprints
- **Database**: MySQL (with automatic parameterized queries & SQLite fallback)
- **AI Core**: Google Gemini API (`google-genai` SDK / Gemini 2.5 Flash / Gemini Vision)
- **APIs**: Google Maps JavaScript API, HTML5 Geolocation API
- **PDF Generation**: ReportLab
- **Authentication**: Flask Sessions, Werkzeug Password Hashing
- **Frontend**: HTML5, Vanilla CSS3, Bootstrap 5, Jinja2 Templates, JavaScript (ES6+), Bootstrap Icons

---

## 📁 Project Structure

```
RESCUEAI/
├── app.py
├── config.py
├── database.py
├── requirements.txt
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── report.html
│   ├── report_result.html
│   ├── chatbot.html
│   ├── shelters.html
│   ├── volunteer.html
│   ├── sos.html
│   ├── alerts.html
│   └── admin/
│       └── dashboard.html
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── script.js
│   ├── images/
│   │   ├── logo.png
│   │   └── hero.jpg
│   └── uploads/
├── routes/
│   ├── auth.py
│   ├── dashboard.py
│   ├── report.py
│   ├── chatbot.py
│   ├── shelters.py
│   ├── volunteer.py
│   ├── sos.py
│   ├── alerts.py
│   └── admin.py
├── chatbot/
│   ├── chatbot.py
│   ├── prompts.py
│   └── ai_service.py
├── services/
│   ├── image_analysis.py
│   ├── report_generator.py
│   ├── notification_generator.py
│   └── pdf_generator.py
├── models/
│   ├── user.py
│   ├── disaster_report.py
│   ├── volunteer.py
│   ├── shelter.py
│   ├── sos.py
│   ├── notification.py
│   └── chat_history.py
└── uploads/
```

---

## 🚀 Quick Setup & Installation Guide

### 1. Install Dependencies

In your terminal or command prompt, navigate to the project directory and run:

```bash
pip install -r requirements.txt
```

### 2. Configure Environment Variables (Optional API Keys)

Set your Gemini API Key and Google Maps API Key in `config.py` or create a `.env` file in the root directory:

```env
GEMINI_API_KEY=your_gemini_api_key_here
GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=root
MYSQL_DB=rescueai_db
```

*(Note: If MySQL is not currently running locally, RESCUEAI automatically initializes an embedded SQLite fallback database `rescueai.db` so you can test all features immediately without configuration errors.)*

### 3. Run Application

Launch the Flask development server:

```bash
python app.py
```

Open your browser and navigate to:
**`http://127.0.0.1:5000`**

---

## 🔑 Demo Credentials

- **System Administrator Account**:
  - **Email**: `admin@rescueai.org`
  - **Password**: `admin123`

---

## 🛡️ Database Tables Overview

- `users`: User profiles, email, phone, hashed password, role (`user`/`admin`).
- `disaster_reports`: User reports, location, image filename, severity rating, verification status.
- `sos_requests`: Panic beacon logs, GPS latitude & longitude, response status.
- `shelters`: Relief shelters, capacity metrics, latitude, longitude.
- `volunteers`: Registered relief workers, skills, availability.
- `notifications`: Public broadcast emergency alerts.
- `chat_history`: Historical user interaction logs with Gemini AI.
- `ai_reports`: Stored AI damage summaries and emergency guidance.

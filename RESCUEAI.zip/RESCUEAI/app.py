import os
import logging
from flask import Flask, render_template, session
from config import Config
from database import init_db

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('rescueai_app')

def create_app():
    """Application factory initializing Flask app, blueprints, database, and routes."""
    app = Flask(__name__)
    app.config.from_object(Config)

    # Ensure upload folder exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Initialize Database Tables
    with app.app_context():
        try:
            init_db()
        except Exception as e:
            logger.error(f"Database initialization error: {e}")

    # Register Blueprints
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.report import report_bp
    from routes.chatbot import chatbot_bp
    from routes.shelters import shelters_bp
    from routes.volunteer import volunteer_bp
    from routes.sos import sos_bp
    from routes.alerts import alerts_bp
    from routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(report_bp)
    app.register_blueprint(chatbot_bp)
    app.register_blueprint(shelters_bp)
    app.register_blueprint(volunteer_bp)
    app.register_blueprint(sos_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(admin_bp)

    # Homepage Route
    @app.route('/')
    def index():
        from models.notification import Notification
        from models.disaster_report import DisasterReport
        from models.shelter import Shelter
        from models.volunteer import Volunteer

        recent_alerts = Notification.get_latest_notifications(limit=3)
        recent_reports = DisasterReport.get_recent(limit=4)
        total_reports = DisasterReport.get_total_count()
        total_shelters = Shelter.get_total_count()
        total_volunteers = Volunteer.get_total_count()

        return render_template(
            'index.html',
            recent_alerts=recent_alerts,
            recent_reports=recent_reports,
            total_reports=total_reports,
            total_shelters=total_shelters,
            total_volunteers=total_volunteers
        )

    # Global Context Processors (Session info & site branding)
    @app.context_processor
    def inject_global_vars():
        return dict(
            current_user=dict(
                id=session.get('user_id'),
                name=session.get('user_name'),
                role=session.get('user_role'),
                email=session.get('user_email')
            ),
            site_name="RESCUEAI",
            emergency_helpline="112"
        )

    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('base.html', page_error="404 - Page Not Found"), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('base.html', page_error="500 - Internal Server Error"), 500

    return app

app = create_app()

if __name__ == '__main__':
    print("=" * 60)
    print("RESCUEAI - AI-Powered Disaster Response & Emergency System")
    print("Starting local server at: http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=True)

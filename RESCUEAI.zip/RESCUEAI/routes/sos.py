from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for
from models.sos import SOSRequest

sos_bp = Blueprint('sos', __name__)

@sos_bp.route('/sos', methods=['GET', 'POST'])
def index():
    """Renders the emergency SOS panic page and logs GPS coordinates upon button trigger."""
    user_id = session.get('user_id')
    active_sos_list = SOSRequest.get_active_sos()

    if request.method == 'POST':
        lat = request.form.get('latitude', '0.0000')
        lng = request.form.get('longitude', '0.0000')

        if not user_id:
            # Allow anonymous guest SOS trigger
            user_id = None

        sos_id = SOSRequest.create_sos(user_id, lat, lng)
        if sos_id:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({
                    'success': True,
                    'message': 'SOS EMERGENCY SIGNAL BROADCASTED SUCCESSFULLY! Dispatching rescue teams.',
                    'sos_id': sos_id
                })
            flash('SOS SIGNAL TRANSMITTED! Emergency rescue responders have been notified of your location.', 'danger')
            return redirect(url_for('sos.index'))
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Failed to log SOS'}), 500
            flash('Could not transmit SOS. Please call Helpline 112 immediately.', 'danger')

    return render_template('sos.html', active_sos_list=active_sos_list)

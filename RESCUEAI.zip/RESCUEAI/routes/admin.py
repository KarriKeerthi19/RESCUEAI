from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from models.user import User
from models.disaster_report import DisasterReport
from models.shelter import Shelter
from models.volunteer import Volunteer
from models.sos import SOSRequest
from models.notification import Notification
from services.notification_generator import generate_ai_summary_all_reports, generate_public_emergency_alert

admin_bp = Blueprint('admin', __name__)

def is_admin():
    return session.get('user_role') == 'admin'

@admin_bp.route('/admin/dashboard')
def dashboard():
    """Renders the comprehensive Admin Command Center panel."""
    if not is_admin():
        flash('Access restricted to System Administrators only.', 'danger')
        return redirect(url_for('auth.login'))

    users = User.get_all_users()
    reports = DisasterReport.get_all_reports()
    shelters = Shelter.get_all_shelters()
    volunteers = Volunteer.get_all_volunteers()
    sos_requests = SOSRequest.get_all_sos()
    notifications = Notification.get_all_notifications()

    # AI Summary if generated previously
    ai_executive_summary = session.get('last_ai_executive_summary', '')

    return render_template(
        'admin/dashboard.html',
        users=users,
        reports=reports,
        shelters=shelters,
        volunteers=volunteers,
        sos_requests=sos_requests,
        notifications=notifications,
        ai_executive_summary=ai_executive_summary
    )

@admin_bp.route('/admin/generate_summary', methods=['POST'])
def generate_summary():
    """Triggers Gemini AI Summarizer for all active disaster reports."""
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 403

    reports = DisasterReport.get_all_reports()
    summary = generate_ai_summary_all_reports(reports)
    session['last_ai_executive_summary'] = summary

    flash('Gemini AI Executive Summary generated successfully!', 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/admin/broadcast_alert', methods=['POST'])
def broadcast_alert():
    """Generates and broadcasts public emergency notifications using Gemini AI."""
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 403

    disaster_type = request.form.get('disaster_type', 'Emergency Incident')
    region = request.form.get('region', 'Affected Sector')
    severity = request.form.get('severity', 'High')

    alert_text = generate_public_emergency_alert(disaster_type, region, severity)
    title = f"🚨 {severity.upper()} ALERT: {disaster_type} in {region}"

    Notification.create_notification(title, alert_text)
    flash(f"Public Emergency Broadcast sent: '{title}'", 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/admin/report/status/<int:report_id>/<string:status>')
def update_report_status(report_id, status):
    """Updates disaster report verification status."""
    if not is_admin():
        flash('Unauthorized', 'danger')
        return redirect(url_for('auth.login'))

    DisasterReport.update_status(report_id, status)
    flash(f"Report #{report_id} status updated to '{status}'.", 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/admin/sos/status/<int:sos_id>/<string:status>')
def update_sos_status(sos_id, status):
    """Updates SOS request status."""
    if not is_admin():
        flash('Unauthorized', 'danger')
        return redirect(url_for('auth.login'))

    SOSRequest.update_status(sos_id, status)
    flash(f"SOS Request #{sos_id} updated to '{status}'.", 'success')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/admin/shelter/add', methods=['POST'])
def add_shelter():
    """Adds a new emergency shelter."""
    if not is_admin():
        return redirect(url_for('auth.login'))

    name = request.form.get('name')
    address = request.form.get('address')
    capacity = request.form.get('capacity', 100)
    lat = request.form.get('latitude', '28.6139')
    lng = request.form.get('longitude', '77.2090')

    if name and address:
        Shelter.create_shelter(name, address, capacity, lat, lng)
        flash(f"Shelter '{name}' added to registry.", 'success')

    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/admin/shelter/delete/<int:shelter_id>')
def delete_shelter(shelter_id):
    """Deletes shelter record."""
    if not is_admin():
        return redirect(url_for('auth.login'))

    Shelter.delete_shelter(shelter_id)
    flash('Shelter deleted.', 'info')
    return redirect(url_for('admin.dashboard'))

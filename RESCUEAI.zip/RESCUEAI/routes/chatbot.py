from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, session
from chatbot.chatbot import DisasterChatbot
from models.chat_history import ChatHistory

chatbot_bp = Blueprint('chatbot', __name__)

@chatbot_bp.route('/chatbot')
def index():
    """Renders the AI Emergency Chatbot page with historical chat context."""
    user_id = session.get('user_id')
    history = ChatHistory.get_by_user(user_id) if user_id else []
    return render_template('chatbot.html', chat_history=history)

@chatbot_bp.route('/chatbot/ask', methods=['POST'])
def ask():
    """AJAX endpoint processing prompt requests and returning structured Gemini AI responses."""
    data = request.get_json() or {}
    question = data.get('question', '').strip()
    user_id = session.get('user_id')

    if not question:
        return jsonify({'error': 'Empty question'}), 400

    # Build conversation context from recent exchanges
    context_str = ""
    if user_id:
        recent_chats = ChatHistory.get_by_user(user_id, limit=4)
        if recent_chats:
            context_str = "\n".join([f"User: {c['question']}\nAI: {c['answer']}" for c in recent_chats])
    else:
        # Session memory for guest users
        guest_history = session.get('guest_chat_history', [])
        if guest_history:
            context_str = "\n".join([f"User: {c['question']}\nAI: {c['answer']}" for c in guest_history[-4:]])

    answer = DisasterChatbot.get_response(user_id, question, chat_history_context=context_str)

    # Store guest session history if not logged in
    if not user_id:
        guest_history = session.get('guest_chat_history', [])
        guest_history.append({'question': question, 'answer': answer})
        session['guest_chat_history'] = guest_history[-10:]

    timestamp = datetime.now().strftime("%I:%M %p")

    return jsonify({
        'question': question,
        'answer': answer,
        'timestamp': timestamp
    })

@chatbot_bp.route('/chatbot/clear', methods=['POST'])
def clear_history():
    """Clears conversation history for logged-in or guest users."""
    user_id = session.get('user_id')
    if user_id:
        ChatHistory.clear_user_chat(user_id)
    session.pop('guest_chat_history', None)
    return jsonify({'success': True, 'message': 'Chat history cleared.'})

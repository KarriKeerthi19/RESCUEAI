from flask import Blueprint, render_template
from models.shelter import Shelter
from config import Config

shelters_bp = Blueprint('shelters', __name__)

@shelters_bp.route('/shelters')
def index():
    """Renders interactive Google Maps shelter locator page with nearby hospitals, police & fire stations."""
    shelter_list = Shelter.get_all_shelters() or []
    google_maps_key = Config.GOOGLE_MAPS_API_KEY
    
    return render_template(
        'shelters.html',
        shelters=shelter_list,
        google_maps_key=google_maps_key
    )

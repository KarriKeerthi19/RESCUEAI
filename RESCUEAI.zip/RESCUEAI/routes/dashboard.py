from flask import Blueprint, render_template, session, redirect, url_for, flash
from models.disaster_report import DisasterReport
from models.sos import SOSRequest
from models.shelter import Shelter
from models.volunteer import Volunteer
from models.notification import Notification

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
def index():
    """Renders the main User Dashboard with stats, recent reports, active SOS alerts, and quick actions."""
    if 'user_id' not in session:
        flash('Please login to access your dashboard.', 'info')
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    
    # Statistics
    total_reports = DisasterReport.get_total_count()
    active_sos = SOSRequest.get_total_active_count()
    total_shelters = Shelter.get_total_count()
    total_volunteers = Volunteer.get_total_count()
    
    # Recent User Reports & Broadcast Alerts
    user_reports = DisasterReport.get_by_user(user_id)
    recent_alerts = Notification.get_latest_notifications(limit=5)
    nearby_shelters = Shelter.get_all_shelters()[:4]

    return render_template(
        'dashboard.html',
        total_reports=total_reports,
        active_sos=active_sos,
        total_shelters=total_shelters,
        total_volunteers=total_volunteers,
        user_reports=user_reports,
        recent_alerts=recent_alerts,
        nearby_shelters=nearby_shelters
    )

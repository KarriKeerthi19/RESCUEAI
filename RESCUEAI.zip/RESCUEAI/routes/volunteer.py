from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models.volunteer import Volunteer

volunteer_bp = Blueprint('volunteer', __name__)

@volunteer_bp.route('/volunteer', methods=['GET', 'POST'])
def index():
    """Renders volunteer sign-up and active task assignment page."""
    user_id = session.get('user_id')
    user_volunteer = Volunteer.get_by_user_id(user_id) if user_id else None

    if request.method == 'POST':
        if not user_id:
            flash('Please login to register as a rescue volunteer.', 'warning')
            return redirect(url_for('auth.login'))

        skills = request.form.get('skills', '').strip()
        availability = request.form.get('availability', 'Immediate').strip()

        if not skills:
            flash('Please specify your rescue skills or resources.', 'danger')
            return render_template('volunteer.html', volunteer=user_volunteer)

        if user_volunteer:
            flash('You are already registered as an active volunteer!', 'info')
        else:
            Volunteer.register_volunteer(user_id, skills, availability)
            flash('Thank you for volunteering! Your profile is active for disaster deployment.', 'success')
            user_volunteer = Volunteer.get_by_user_id(user_id)

    # Sample disaster response tasks
    tasks = [
        {"id": 101, "title": "Food & Clean Water Distribution", "location": "Sector 4 Relief Camp", "urgency": "High", "status": "Active"},
        {"id": 102, "title": "First Aid & Medical Triage Assist", "location": "St. Jude Shelter", "urgency": "Critical", "status": "In Progress"},
        {"id": 103, "title": "Debris Clearing & Pathway Marking", "location": "Northside Bridge Corridor", "urgency": "Medium", "status": "Open"},
        {"id": 104, "title": "Elderly & Vulnerables Evacuation", "location": "River Valley Sector 1", "urgency": "High", "status": "Active"}
    ]

    return render_template('volunteer.html', volunteer=user_volunteer, tasks=tasks)

import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, send_file
from werkzeug.utils import secure_filename
from config import Config
from models.disaster_report import DisasterReport
from services.image_analysis import analyze_disaster_image
from services.report_generator import generate_ai_damage_report
from services.pdf_generator import generate_pdf_report

report_bp = Blueprint('report', __name__)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS

@report_bp.route('/report', methods=['GET', 'POST'])
def create_report():
    """Renders disaster report submission page and processes image upload + AI analysis."""
    if 'user_id' not in session:
        flash('Please log in to submit a disaster report.', 'warning')
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        location = request.form.get('location', '').strip()
        severity = request.form.get('severity', 'Medium')
        
        file = request.files.get('image')
        filename = ''

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
            save_path = os.path.join(Config.UPLOAD_FOLDER, filename)
            file.save(save_path)
        else:
            filename = 'default_disaster.jpg'

        if not title or not description or not location:
            flash('Please complete all required fields (Title, Description, Location).', 'danger')
            return render_template('report.html')

        # Insert report to DB
        user_id = session['user_id']
        report_id = DisasterReport.create_report(user_id, title, description, filename, location, severity)

        if report_id:
            # Perform Gemini Vision AI Image Analysis & Damage Report
            image_full_path = os.path.join(Config.UPLOAD_FOLDER, filename) if filename != 'default_disaster.jpg' else ''
            vision_result = analyze_disaster_image(image_full_path) if image_full_path else {
                "disaster_type": title,
                "severity": severity,
                "objects_detected": ["Reported Incident Site"],
                "damage_summary": description,
                "confidence": "90%",
                "emergency_guidance": "Follow local emergency authority evacuation orders."
            }

            ai_damage_report = generate_ai_damage_report(title, description, location, severity, vision_result)

            # Store AI Summary in database
            DisasterReport.save_ai_summary(report_id, ai_damage_report, vision_result.get('emergency_guidance', ''))

            flash('Disaster Report logged successfully! AI Analysis Complete.', 'success')
            return redirect(url_for('report.view_result', report_id=report_id))
        else:
            flash('Failed to submit report. Please try again.', 'danger')

    return render_template('report.html')

@report_bp.route('/report/result/<int:report_id>')
def view_result(report_id):
    """Renders the AI Analysis Result Page showing image, severity, objects detected, damage report, and guidance."""
    report = DisasterReport.get_by_id(report_id)
    if not report:
        flash('Report not found.', 'danger')
        return redirect(url_for('dashboard.index'))

    ai_summary_record = DisasterReport.get_ai_summary(report_id)
    
    # Image analysis mock or re-run
    image_full_path = os.path.join(Config.UPLOAD_FOLDER, report['image']) if report['image'] else ''
    vision_result = analyze_disaster_image(image_full_path) if (image_full_path and os.path.exists(image_full_path)) else {
        "disaster_type": report['title'],
        "severity": report['severity'],
        "objects_detected": ["Incident Corridor", "Debris", "Utility Poles"],
        "damage_summary": report['description'],
        "confidence": "93.8%",
        "emergency_guidance": "Seek elevated shelter, conserve emergency kit rations, notify family."
    }

    ai_text = ai_summary_record['summary'] if ai_summary_record else generate_ai_damage_report(
        report['title'], report['description'], report['location'], report['severity'], vision_result
    )

    return render_template(
        'report_result.html',
        report=report,
        vision=vision_result,
        ai_text=ai_text
    )

@report_bp.route('/report/pdf/<int:report_id>')
def download_pdf(report_id):
    """Generates and serves downloadable PDF report."""
    report = DisasterReport.get_by_id(report_id)
    if not report:
        flash('Report not found for PDF download.', 'danger')
        return redirect(url_for('dashboard.index'))

    ai_summary_record = DisasterReport.get_ai_summary(report_id)
    ai_text = ai_summary_record['summary'] if ai_summary_record else "AI Assessment Pending."

    pdf_buffer = generate_pdf_report(report, ai_text)
    return send_file(
        pdf_buffer,
        as_attachment=True,
        download_name=f"RESCUEAI_Damage_Report_{report_id}.pdf",
        mimetype='application/pdf'
    )

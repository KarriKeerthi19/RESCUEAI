from flask import Blueprint, render_template
from models.notification import Notification

alerts_bp = Blueprint('alerts', __name__)

@alerts_bp.route('/alerts')
def index():
    """Renders latest public disaster broadcast alerts and advisory bulletins."""
    notifications = Notification.get_all_notifications()
    return render_template('alerts.html', notifications=notifications)
